from google.cloud import bigquery
from typing import Dict, List


class DependentQueryExecutor:
    def __init__(self, project_id: str):
        self.client = bigquery.Client(project=project_id)

    def execute_query(self, query: str) -> bool:
        """Esegue una query e restituisce True se è completata con successo."""
        try:
            job = self.client.query(query)
            job.result()  # Attende la fine della query
            print(f"Query {job.job_id} completata.")
            return True
        except Exception as e:
            print(f"Errore nell'esecuzione della query: {e}")
            return False

    def execute_with_dependencies(
        self, dependency_graph: Dict[str, List[str]]
    ):
        """
        Esegue un insieme di query con dipendenze specificate.

        :param dependency_graph: Dizionario in cui ogni chiave è una query e il valore è una lista di query che devono essere eseguite prima.
        """
        executed_queries = set()

        def execute_query_with_dependencies(query: str):
            if query in executed_queries:
                return True

            dependencies = dependency_graph.get(query, [])
            for dependency in dependencies:
                if dependency not in executed_queries:
                    success = execute_query_with_dependencies(dependency)
                    if not success:
                        print(
                            f"Query dipendente {dependency} fallita. Interruzione."
                        )
                        return False

            if self.execute_query(query):
                executed_queries.add(query)
                return True
            return False

        for query in dependency_graph:
            if query not in executed_queries:
                execute_query_with_dependencies(query)


# Esempio di utilizzo
if __name__ == "__main__":
    project_id = "lmit-bi-cdg-itlm"

    # Definizione del grafo delle dipendenze
    dependency_graph = {
        "SELECT 1": [],  # Nessuna dipendenza
        "SELECT 2": ["SELECT 1"],  # B dipende da A
        "SELECT 3": ["SELECT 1", "SELECT 2"],  # C dipende da A e B
    }

    executor = DependentQueryExecutor(project_id)
    executor.execute_with_dependencies(dependency_graph)
