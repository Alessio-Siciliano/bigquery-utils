import numpy

print("1")


class ab:
    pass
