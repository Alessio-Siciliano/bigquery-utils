""" Version of the module """

__version__ = "0.0.1"
